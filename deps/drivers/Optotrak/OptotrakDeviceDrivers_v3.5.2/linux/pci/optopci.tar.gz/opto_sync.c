#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <unistd.h>

#include "optopci.h"

int main( int argc, char **argv )
{
	pid_t pid;
	int duration, old, fd, i, j, ret;
	struct timeval tvold, tvnow;

	fd = open("/dev/optopci", O_RDWR);
	if(fd < 0) {
		perror("open");
		return -1;
	}
	sync();
	sleep(1);

	switch(pid = fork()) {
	case -1:
		perror( "fork");
		break;
	case 0:
		old = 0;
		gettimeofday(&tvold, 0);
		for(j=0; j<10; j++) {
			ret = ioctl(fd, OPTOPCI_LINK_STAT, &i);
			if(ret < 0) {
				printf("ioctl returned %d\n", ret);
				return -1;
			}
			if(old != i) {
				gettimeofday(&tvnow, 0);
				duration = tvnow.tv_usec - tvold.tv_usec;
				if(duration < 0)
					duration += 1000000;
				tvold = tvnow;
				printf("%d   %02x\n", duration, i);
				old = i;
			}
		}
		break;
	default:
		for(j=0; j<10; j++) {
			ret = ioctl(fd, OPTOPCI_LINK_RESET, 0);
			if(ret < 0) {
				printf("ioctl returned %d\n", ret);
				return -1;
			}
			sleep(1);
		}
		break;
	}
	
	close(fd);
	return 0;
}
