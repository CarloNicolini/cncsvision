/*******************************************************************************
Name:
	optotrak.c

Description
	Optotrak/PCI interface driver for Linux

	Copyright (c) 2004 Northern Digital Inc. All rights reserved..

	Confidential and proprietary. 

	Not for distribution outside of NDI without proper permission.
*******************************************************************************/

/*******************************************************************************
System library includes
*******************************************************************************/
#ifdef KERNEL_VER_2_4_X
#include <linux/config.h>
#include <linux/errno.h>
#endif
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/version.h>
#include <linux/pci.h>
#include <linux/interrupt.h>
#include <asm/uaccess.h>
#ifndef __devinit
#include <linux/init.h>
#endif

#define MAX_TO 44

/*******************************************************************************
Defines
*******************************************************************************/

/*******************************************************************************
Project files included
*******************************************************************************/
#include "optotrak.h"

/*******************************************************************************
This block is needed for compatability between 2.4.x and 2.6.x kernels.

If we are using 2.6.x sources, irqreturn_t is defined for us AND request_irq()'s
second argument, a function pointer, is defined as having a return type of
'irqreturn_t'. 2.4.x source defines that function pointer as having a return
type of 'void'
********************************************************************************/ 
#ifdef KERNEL_VER_2_4_X
#define OPTOPCI_IRQ_RETURN_TYPE void
#define RETURN_OPTOPCI_IRQ( x ) return
#define IRQ_HANDLED
#define IRQ_NONE
#else
#define OPTOPCI_IRQ_RETURN_TYPE irqreturn_t
#define RETURN_OPTOPCI_IRQ( x ) return x
#endif

ssize_t optopci_read( struct file *file, char *buff, size_t size, loff_t *off );
ssize_t optopci_write( struct file *file, const char *buff, size_t size, loff_t *off );
int optopci_ioctl( struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg);
int optopci_open( struct inode *inode, struct file *file );
int optopci_release( struct inode *in, struct file *file );
static void __devexit optopci_remove(struct pci_dev *pci_dev);
static int __devinit optopci_probe( struct pci_dev *pci_dev, const struct pci_device_id *pci_id );
void __devexit exit_optotrak( void );
int __devinit init_optotrak( void );

module_init( init_optotrak );
module_exit( exit_optotrak );

/*******************************************************************************
Globals
*******************************************************************************/
static char
	driver_name[]="optotrak-pci";
static struct
	optotrak_dev *char_dev[MAX_CARDS];
unsigned int
	uMajor = -1;
static struct file_operations opto_fops = {
	read:    optopci_read,
	write:   optopci_write,
	ioctl:   optopci_ioctl,
	open:    optopci_open,
	release: optopci_release,
	owner:   THIS_MODULE,
};
static struct pci_device_id optopci_tbl[] = {
	{ OPTOPCI_VENDOR_ID, OPTOPCI_DEVICE_ID, PCI_ANY_ID, PCI_ANY_ID, 0, 0, 0 },
	{ 0, }
};
struct pci_driver optotrak_pci_driver = {
	name:driver_name,
	id_table:optopci_tbl,
	probe:optopci_probe,
	remove:optopci_remove,
};

MODULE_AUTHOR("Vitor Angelo");
MODULE_DESCRIPTION("Optotrak/PCI interface driver");
MODULE_LICENSE("Proprietary");
MODULE_DEVICE_TABLE( pci, optopci_tbl );

/*******************************************************************************
Name:
	set_read_irq

Description
*******************************************************************************/
static inline void set_read_irq( struct optotrak_dev *dev, int n )
{
	unsigned long
		flags;
	unsigned char
		fifo;	
	int
		thresh;

	if ( n )
	{
		thresh = ( ( n - 4 ) >> 4 ) + 1;
		if ( thresh > PCI_FIFO_THRESH_MAX )
		{
			thresh = PCI_FIFO_THRESH_MAX;
		} /* if */
	} /* if */
	else
	{
		thresh = 0;
	} /* else */

	spin_lock_irqsave( & ( dev->lock ), flags );
	fifo = inb( dev->fifoio );
	fifo &= PCI_FIFO_WRITE_INT_EN;
	fifo |= thresh | PCI_FIFO_READ_INT_EN;
	outb( fifo, dev->fifoio );
	wake_up_interruptible( &( dev->writeq ) );
	spin_unlock_irqrestore( &( dev->lock ), flags );

} /* set_read_irq */

/*******************************************************************************
Name:
	optopci_read

Description
	The library expects full read or failure
*******************************************************************************/
ssize_t optopci_read( struct file *pdtFile, char *uchBuff, size_t size, loff_t *off )
{
	struct optotrak_dev
		*pdtOptoData;
	ssize_t
		n = 0,
		nBytesLeft = 0,
		nBytesRead = 0,
		nError = 0;
	unsigned int
		*puOptoBuf = 0;
	unsigned char
		*puchOptoBuf = 0;
	unsigned char
		uchFifo = 0,
		uchLink = 0;
	int
		nTo = 0;	

	if( size == 0 )
	{
		return 0;
	} /* if */
	
	nBytesLeft = size;
	if( nBytesLeft > READ_BUFF )
	{
		nBytesLeft = READ_BUFF;
	} /* if */

	pdtOptoData = pdtFile->private_data;
	if( down_interruptible( &( pdtOptoData->rsem ) ) )
	{
		nError = -EINVAL;
		goto finish;
	} /* if */	
	
	while( nBytesLeft > 3 )
	{
		/*
		 * point our local buffer to the optodata read buffer
		 */
		puOptoBuf = ( unsigned int *)pdtOptoData->rbuffer;		      

		/*
		 * determine next read size
		 */
		uchLink = inb( pdtOptoData->linkio );
		
		n = nBytesLeft;        
		while( n > 3 )
		{
			if( uchLink & PCI_LC_READABLE_4 )
			{
				/*
				 * read the data
				 */ 
				*puOptoBuf = inl( pdtOptoData->dataio );
				puOptoBuf++;				
				
				nBytesRead += 4;
				nBytesLeft -= 4;				
				n -= 4;	
				
				uchLink = inb( pdtOptoData->linkio );
				continue;
			} /* if */

			set_read_irq( pdtOptoData, n );

			for( nTo = 1; ; nTo++ )
			{
				interruptible_sleep_on_timeout( &( pdtOptoData->readq ), nTo );
				if( signal_pending( current ) )
				{ 
					/*
					 * thread was interrupted - return to caller
					 */					
					goto finish;
				} /* if */
				
				uchLink = inb( pdtOptoData->linkio );
				if( uchLink & PCI_LC_READABLE_4 )
				{
					/* 
					 * 4 more bytes to read
					 */					
					break;
				} /* if */

				if( nTo > MAX_TO )
				{
					nError = -EIO;
					goto finish;
				} /* if */
			} /* for to */
		} /* while n > 3 */

		if( nBytesRead )
		{				
			update_atime( pdtFile->f_dentry->d_inode );			
		} /* if */
	} /* while size > 3 */

    if( nBytesLeft == 0 )
	{
		goto finish;
	} /* if */

	
	uchLink = inb( pdtOptoData->linkio );
	/*
	 * all data read now, should be 1 byte per, so lets point
	 * the char buffer at the optodata buf, offset by the number
	 * of bytes read above
	 */
	puchOptoBuf = pdtOptoData->rbuffer + nBytesRead;	

	while( nBytesLeft > 0 )
	{
		if( uchLink & PCI_LC_READABLE_1 )
		{
			*puchOptoBuf = inb( pdtOptoData->dataio );
			puchOptoBuf++;
			nBytesRead += 1;
			nBytesLeft -= 1;			
			
			uchLink = inb( pdtOptoData->linkio );
			continue;
		} /* if */

		set_read_irq( pdtOptoData, 0 );

		for( nTo = 1; ; nTo++ )
		{
			interruptible_sleep_on_timeout( &( pdtOptoData->readq ), nTo );
			if( signal_pending( current ) ) 
			{								
				goto finish;
			} /* if */

			uchLink = inb( pdtOptoData->linkio );
			if( ( uchLink & PCI_LC_READABLE_1 ) )
			{
				break;
			} /* if */

			if( nTo > MAX_TO )                            
			{
				nError = -EIO;
				goto finish;
			} /* if */
		} /* for */
	} /* while */	

finish:
	if( nError )
	{
		return nError;
	} /* if */
	
	if( nBytesRead > 0 )
	{
		update_atime( pdtFile->f_dentry->d_inode );
		if( copy_to_user( uchBuff, pdtOptoData->rbuffer, nBytesRead ) )
		{
			return -EFAULT;
		} /* if */
	} /* if */
	else
	{
		unsigned long
			flags;

		spin_lock_irqsave( &( pdtOptoData->lock ), flags );
		uchFifo = inb( pdtOptoData->fifoio );
		uchFifo &= ~PCI_FIFO_READ_INT_EN;
		outb( uchFifo, pdtOptoData->fifoio );
		spin_unlock_irqrestore( &( pdtOptoData->lock ), flags );
	} /* else */

	up( &pdtOptoData->rsem );

    return nBytesRead;

} /* optopci_read */

/*******************************************************************************
Name:
	set_write_irq

Description
*******************************************************************************/
static inline void set_write_irq( struct optotrak_dev *dev )
{
	unsigned long
		flags;
	unsigned char
		fifo;
	
	spin_lock_irqsave( &( dev->lock ), flags );
	fifo = inb( dev->fifoio );
	fifo |= PCI_FIFO_WRITE_INT_EN;
	outb( fifo, dev->fifoio );
	wake_up_interruptible( &( dev->readq ) );
	spin_unlock_irqrestore( &( dev->lock ), flags );

} /* set_write_irq */

/*******************************************************************************
Name:
	optopci_write

Description
	The library expects full read or failure
*******************************************************************************/
ssize_t optopci_write( struct file *pdtFile, const char *puchBuff, size_t size, loff_t *off )
{
	struct optotrak_dev
		*pdtOptoData;
	ssize_t
		nBytesLeft = 0,
		nBytesWrote = 0,
		nError = 0,
		n = 0;
	unsigned int
		*puOptoBuf = 0;
	unsigned char
		*puchOptoBuf = 0;
	unsigned char
		uchFifo = 0,
		uchLink = 0;
	int
		nTo = 0;	

	if( size == 0 )
	{
		return 0;
	} /* if */	
	
	nBytesLeft = size;
	if( nBytesLeft > WRITE_BUFF )
	{
		nBytesLeft = WRITE_BUFF;
	} /* if */
	
	pdtOptoData = pdtFile->private_data;

	if( down_interruptible( &( pdtOptoData->wsem ) ) )
	{
		nError = -EINVAL;
		goto finish;
	} /* if */	
	
	if( copy_from_user( pdtOptoData->wbuffer, puchBuff, nBytesLeft ) )
	{
		nError = -EFAULT;
		goto finish;
	} /* if */	
	
	while( nBytesLeft > 3 )
	{	
		puOptoBuf = ( unsigned int* )pdtOptoData->wbuffer;
		uchLink = inb( pdtOptoData->linkio );	
		
		n = nBytesLeft;
		while( n > 3 )
		{
			if( uchLink & PCI_LC_WRITABLE_4 )
			{
				outl( *puOptoBuf, pdtOptoData->dataio );
				puOptoBuf++;
				
				nBytesWrote += 4;
				nBytesLeft -= 4;
				n -= 4;				
				
				uchLink = inb( pdtOptoData->linkio );
				continue;
			} /* if */

			set_write_irq( pdtOptoData );
			
			for( nTo = 1; ; nTo++ )
			{
				interruptible_sleep_on_timeout( &( pdtOptoData->writeq ), nTo );
				if( signal_pending( current ) )
				{					
					goto finish;
				} /* if */

				uchLink = inb( pdtOptoData->linkio );

				if( uchLink & PCI_LC_WRITABLE_4 )
				{
					break;
				} /* if */

				if( nTo > MAX_TO )
				{
					nError = -EIO;
					goto finish;
				} /* if */
			} /* for nTo */
		} /* while n > 3 */

	} /* while nBytesLeft */


	if( nBytesLeft == 0 )
	{
		goto finish;
	} /* if */
	
	uchLink = inb( pdtOptoData->linkio );
	puchOptoBuf = pdtOptoData->wbuffer + nBytesWrote;

	while( nBytesLeft > 0)
	{
		if( uchLink & PCI_LC_WRITABLE_4 )
		{
			outb( *puchOptoBuf, pdtOptoData->dataio );
			puchOptoBuf++;
			
			nBytesLeft -= 1;
			nBytesWrote += 1;
			
			uchLink = inb( pdtOptoData->linkio );
			continue;
		} /* if */

		set_write_irq( pdtOptoData );

		for( nTo = 1; ; nTo++ )
		{
			interruptible_sleep_on_timeout( &( pdtOptoData->writeq ), nTo );

			if( signal_pending( current ) )
			{
				goto finish;
			} /* if */

			uchLink = inb( pdtOptoData->linkio );

			if( uchLink & PCI_LC_WRITABLE_4 )
			{
				break;
			} /* if */

			if( nTo > MAX_TO )
			{
				nError = -EIO;
				goto finish;
			} /* if */
		} /* for nTo */
	} /* while n > 0*/	

finish:
	if( nError )
	{
		return nError;
	} /* if */
	
	if( nBytesWrote < 0 )
	{
		unsigned long
			flags;
	
		spin_lock_irqsave( &( pdtOptoData->lock ), flags );
		uchFifo = inb( pdtOptoData->fifoio );
		uchFifo &= ~PCI_FIFO_WRITE_INT_EN;
		outb( uchFifo, pdtOptoData->fifoio );
		spin_unlock_irqrestore( &( pdtOptoData->lock ), flags );
	} /* if */

	up( &pdtOptoData->wsem );

	return nBytesWrote;

} /* optopci_write */

/*******************************************************************************
Name:
	optopci_ioctl

Description
	The library expects full read or failure
*******************************************************************************/
int optopci_ioctl( struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg)
{
	struct optotrak_dev
		*dev = file->private_data;
	unsigned char
		byte;
	signed long
		time;

	if( ( cmd == OPTOPCI_FIFO_STAT) || ( cmd == OPTOPCI_LINK_STAT ) )
	{
		if ( _IOC_DIR( cmd ) & _IOC_WRITE )
		{
			if( !access_ok( VERIFY_WRITE, ( void * )arg, _IOC_SIZE( cmd ) ) )
			{
				return -EFAULT;
			} /* if */
		} /* if */
	} /* if */

	switch( cmd )
	{
	case OPTOPCI_FIFO_STAT:
		byte = inb( dev->fifoio );
		*(int *)arg = ( int )byte;
		break;
	case OPTOPCI_LINK_STAT:
		*( unsigned long * )arg = 0;
		byte = inb( dev->linkio );
		if( byte & PCI_LC_WRITABLE_4 )
		{
			*( unsigned long * )arg |= OPTOTRAK_WRITE;
		} /* if */
		if( byte & PCI_LC_READABLE_1 )
		{
			*( unsigned long * )arg |= OPTOTRAK_READ;
		} /* if */
		break;
	case OPTOPCI_LINK_RESET:
		byte = inb( dev->linkio );
		byte |= PCI_LC_SYNC_OUT;
		outb (byte, dev->linkio );
		/* wait 100ms */
		time = HZ/10;
		set_current_state( TASK_INTERRUPTIBLE );
		do 
		{
			time = schedule_timeout( time );
		} while( time > 0 );
		byte &= ~PCI_LC_SYNC_OUT;
		byte |= PCI_LC_CARD_RESET;
		outb( byte, dev->linkio );
		byte &= ~PCI_LC_CARD_RESET;
		outb( byte, dev->linkio );
		break;
	case OPTOPCI_CARD_INIT:
		byte = inb( dev->linkio );
		byte |= PCI_LC_CARD_RESET;
		outb( byte, dev->linkio );
		byte &= ~PCI_LC_CARD_RESET;
		outb( byte, dev->linkio );
		break;
	default:
		return -ENOTTY;
	} /* switch */

	return 0;

} /* optopci_ioctl */

/*******************************************************************************
Name:
	optopci_open

Description
*******************************************************************************/
int optopci_open( struct inode *inode, struct file *file )
{
	int
		dev = MINOR( inode->i_rdev );

	if( dev >= MAX_CARDS )
	{
		return -ENODEV;
	} /* if */

	if( file->f_flags & O_NONBLOCK )
	{
		printk( "optopci: open attempt with nonblock flag!\n" );
		return -EACCES;
	} /* if */

	if( down_interruptible( &( char_dev[ dev ]->rsem ) ) )
	{
		return -EBUSY;
	} /* if */

	if( char_dev[ dev ]->status & OPTO_DEV_IN_USE )
	{
		up( &( char_dev[ dev ]->rsem ) );
		return -EBUSY;
	} /* if */

	char_dev[ dev ]->status |= OPTO_DEV_IN_USE;

	init_waitqueue_head( &( char_dev[ dev ]->readq ) );
	init_waitqueue_head( &( char_dev[ dev ]->writeq ) );

	file->private_data = char_dev[ dev ];

	up( &( char_dev[ dev ]->rsem ) );

	return 0;

} /* optopci_open */

/*******************************************************************************
Name:
	optopci_release

Description

*******************************************************************************/
int optopci_release( struct inode *in, struct file *file )
{
	struct optotrak_dev 
		*dev = file->private_data;

	if( down_interruptible( &( dev->rsem ) ) )
	{
		return -EBADF;
	} /* if */

	if( !( dev->status & OPTO_DEV_IN_USE ) )
	{
		up( &( dev->rsem ) );
		return -EBADF;
	} /* if */

	dev->status &= ~OPTO_DEV_IN_USE;
	up( &( dev->rsem ) );

	return 0;

} /* optopci_release */

/*******************************************************************************
Name:
	optopci_irq

Description

*******************************************************************************/
OPTOPCI_IRQ_RETURN_TYPE optopci_irq( int i, void *dev, struct pt_regs *regs )
{		
	struct optotrak_dev
		*info = dev;
	unsigned long
		flags;
	unsigned char
		fifo;

	spin_lock_irqsave( &( info->lock ), flags );

	fifo = inb( info->fifoio );

	if( ( fifo & PCI_FIFO_INT_PENDING ) == 0 )
	{
		spin_unlock_irqrestore(&(info->lock), flags);				
		RETURN_OPTOPCI_IRQ(IRQ_NONE);
	} /* if */

	if( fifo & PCI_FIFO_READ_INT_EN )
	{
		fifo &= ~PCI_FIFO_READ_INT_EN;
		wake_up_interruptible( &( info->readq ) );
	} /* if */

	if( fifo & PCI_FIFO_WRITE_INT_EN )
	{
		fifo &= ~PCI_FIFO_WRITE_INT_EN;
		wake_up_interruptible( &( info->writeq ) );
	} /* if */
	
	outb( fifo, info->fifoio );
	spin_unlock_irqrestore( &( info->lock ), flags );
	
	RETURN_OPTOPCI_IRQ(IRQ_HANDLED);	

} /* optopci_irq */

/*******************************************************************************
Name:
	optopci_probe

Description

*******************************************************************************/
static int __devinit optopci_probe( struct pci_dev *pci_dev, const struct pci_device_id *pci_id )
{
	static int
		lastdev = 0;
	struct optotrak_dev
		*info;
	struct amcc_regs
		amcc;

	if(lastdev >= MAX_CARDS)
	{
		printk( "optopci: %d cards are not supported\n", MAX_CARDS + 1 );
		return -ENODEV;
	} /* if */

	if( pci_enable_device( pci_dev ) )
	{
		return -ENODEV;
	} /* if */

	info = kmalloc( sizeof( struct optotrak_dev ), GFP_KERNEL );

	if( info == NULL )
	{
		goto disable;
	} /* if */
		
#ifndef KERNEL_VER_2_4_X
	pci_dev->dev.driver_data = info;
#else
	pci_dev->driver_data = info;
#endif
	
	char_dev[ lastdev ] = info;

	amcc.omb = pci_dev->resource[ OPTO_PCI_CONTROL ].start + PCI_AMCC_OMB;
	amcc.imb = pci_dev->resource[ OPTO_PCI_CONTROL ].start + PCI_AMCC_IMB;
	amcc.mbef = pci_dev->resource[ OPTO_PCI_CONTROL ].start + PCI_AMCC_MBEF;
	amcc.intcsr = pci_dev->resource[ OPTO_PCI_CONTROL ].start + PCI_AMCC_INTCSR;
	amcc.rcr = pci_dev->resource[ OPTO_PCI_CONTROL ].start + PCI_AMCC_RCR;
	amcc.ptcr = pci_dev->resource[ OPTO_PCI_CONTROL ].start + PCI_AMCC_PTCR;
	info->dataio = pci_dev->resource[ OPTO_PCI_READ_WRITE ].start;
	info->linkio = pci_dev->resource[ OPTO_PCI_LINK_STATUS ].start;
	info->fifoio = pci_dev->resource[ OPTO_PCI_FIFO_STATUS ].start;
	info->crcio = pci_dev->resource[ OPTO_PCI_CRC_GEN ].start;
	info->irq = pci_dev->irq;

	if( pci_request_regions(pci_dev, driver_name ) )
	{
		goto free;
	} /* if */

	spin_lock_init( &( info->lock ) );
	sema_init( &( info->rsem ), 1 );
	sema_init( &( info->wsem ), 1 );
	info->status = 0;
	info->numb = lastdev;

	if( request_irq( info->irq, optopci_irq, SA_SHIRQ | SA_INTERRUPT, driver_name, (void *)info ) )
	{
		goto release;
	} /* if */

	/* disable fifo interrupts */
	outb( 0, info->fifoio );
	if( amcc_setup( &amcc ) ) /* setup amcc PCI adaptor */
	{
		goto irqfree;
	} /* if */

	/* disable fifo interrupts again... */
	outb( 0, info->fifoio );
	lastdev++;

	return 0;

irqfree:
	free_irq(info->irq, info);
release:
	pci_release_regions(pci_dev);
free:
	kfree(info);
disable:
	pci_disable_device(pci_dev);

	return -ENODEV;

} /* optopci_probe */

/*******************************************************************************
Name:
	optopci_remove

Description

*******************************************************************************/
static void __devexit optopci_remove(struct pci_dev *pci_dev)
{
#ifndef KERNEL_VER_2_4_X
	struct optotrak_dev 
		*info = pci_dev->dev.driver_data;
#else
	struct optotrak_dev
		*info = pci_dev->driver_data;
#endif

	free_irq( info->irq, info );
	kfree( info );
	pci_release_regions( pci_dev );
	pci_disable_device( pci_dev );

} /* optopci_remove */

/*******************************************************************************
Name:
	init_optotrak

Description

*******************************************************************************/
int __devinit init_optotrak( void )
{
	int
		cards;	

	/*
	 * pci_present is deprecated and has no use
	 * since the PCI API handles correct behaviour of
	 * no PCI present -- this should be tested
	 */
#if 0
	if( !pci_present() )
	{
		printk( "optopci: PCI not found\n" );
		return -1;
	} /* if */
#endif

	if( ( cards = pci_register_driver( &optotrak_pci_driver ) ) < 1 )
	{
		printk( "optopci: Optotrak PCI interface not found\n" );
		pci_unregister_driver( &optotrak_pci_driver );
		return -1;
	} /* if */

#if 0
	if( register_chrdev( OPTOPCI_MAJOR, driver_name, &opto_fops ) < 0 )
	{
		printk( "optopci: Unable to register optotrak/pci char device\n" );
		pci_unregister_driver( &optotrak_pci_driver );
		return -1;
	} /* if */
#endif

	/*
	 * Pass value of '0', as major device number, so that the kernel
	 * can dynamically allocate a valid number. We can then, manually
	 * create the device file via 'mknod', after parsing /proc/devices
	 * for the number.
	 */        
	uMajor = register_chrdev( 0, driver_name, &opto_fops );
	if ( uMajor == -1 )
	{
		printk( "optopci: Unable to register optotrak/pci char device\n" );
		pci_unregister_driver( &optotrak_pci_driver );
		return -1;
	} /* if */

	printk( "optopci: NDI Optotrak PCI driver loaded. Cards found: %d\n", cards );
	return 0;

} /* init_optotrak */

/*******************************************************************************
Name:
	exit_optotrak

Description

*******************************************************************************/
void __devexit exit_optotrak( void )
{
	unregister_chrdev( uMajor, driver_name );

	pci_unregister_driver( &optotrak_pci_driver );
	printk( "optopci: NDI Optotrak PCI driver unloaded\n" );
	return;

} /* exit_optotrak */                                                                         
