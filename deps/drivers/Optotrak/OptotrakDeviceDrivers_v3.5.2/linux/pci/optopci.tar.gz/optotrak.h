/*
 *  Optotrak/PCI interface driver for Linux
 */

#include "optopci.h"

#define OPTO_DEV_READ			0x0001
#define OPTO_DEV_WRITE			0x0002
#define OPTO_DEV_IN_USE			(OPTO_DEV_READ | OPTO_DEV_WRITE)

#define OPTOPCI_VENDOR_ID		0x10e8
#define OPTOPCI_DEVICE_ID		0x8380

// PCI Card IO resources
#define OPTO_PCI_CONTROL		0
#define OPTO_PCI_READ_WRITE		1
#define OPTO_PCI_LINK_STATUS		2
#define OPTO_PCI_FIFO_STATUS		3
#define OPTO_PCI_CRC_GEN		4

// Link Control Register
#define PCI_LC_CARD_RESET		0x01
#define PCI_LC_CRC_RESET		0x02
#define PCI_LC_SYNC_OUT			0x04
#define PCI_LC_READABLE_4		0x08
#define PCI_LC_XFER_ALARM		0x10
#define PCI_LC_READABLE_1		0x20
#define PCI_LC_WRITABLE_4		0x40
#define PCI_LC_SYNC_IN			0x80

// FIFO Control Register
#define PCI_FIFO_THRESH_MAX		0x1f
#define PCI_FIFO_WRITE_INT_EN		0x20
#define PCI_FIFO_READ_INT_EN		0x40
#define PCI_FIFO_INT_PENDING		0x80

// AMCC info
#define PCI_CLOCK_BIT           0x80000000
#define PCI_READ_BACK           0x40000000
#define PCI_RESET_ATMEL_EEPROM  0x20000000
#define PCI_SER_EN              0x10000000
#define PCI_START               0x08000000
#define PCI_DATA_BIT            0x01000000

#define PCI_AMCC_PTCR           0x60l
#define PCI_AMCC_PTCR_DEFAULT   0x21212100
#define PCI_AMCC_RCR            0x3Cl
#define PCI_AMCC_RCR_DEFAULT    0x00000000
#define PCI_AMCC_INTCSR         0x38l
#define PCI_AMCC_INTCSR_DEFAULT 0x00000F1F
#define PCI_AMCC_ENABLE_PT_INT	0x00002F0F
#define PCI_AMCC_OMB       	0x0C
#define PCI_AMCC_IMB            0x1C
#define PCI_AMCC_MBEF           0x34

#define EEPROM_NUM_PAGES	512
#define EEPROM_PAGE_SIZE	128
#define EEPROM_WRITE_ADDRESS	0xa6
#define EEPROM_READ_ADDRESS	0xa7



/*#include <linux/errno.h>*/
/*#include <linux/ioctl.h>*/
/*#include <linux/wait.h>*/
/*#include <linux/spinlock.h>*/
/*#include <linux/ioport.h>*/
/*#include <asm/io.h>*/
/*#include <asm/semaphore.h>*/

#undef		DEBUG_IRQ
#undef		DEBUG_INIT
#undef		DEBUG_OPEN
#undef		DEBUG_READ
#undef		DEBUG_WRITE
#undef		DEBUG_IOCTL
#define		DEBUG_STATS

#define READ_BUFF	4096
#define WRITE_BUFF	READ_BUFF

struct amcc_regs {
	unsigned long omb;
	unsigned long imb;
	unsigned long mbef;
	unsigned long intcsr;
	unsigned long rcr;
	unsigned long ptcr;
	};

struct optotrak_dev {
	unsigned char irq;
	unsigned long dataio;
	unsigned long linkio;
	unsigned long fifoio;
	unsigned long crcio;
	int status, numb;
	struct semaphore rsem;
	struct semaphore wsem;
	unsigned char rbuffer[READ_BUFF];
	unsigned char wbuffer[WRITE_BUFF];
	wait_queue_head_t readq, writeq;
	spinlock_t lock;
};

/* function exported from amcc.c */
int amcc_setup(struct amcc_regs *amcc);
