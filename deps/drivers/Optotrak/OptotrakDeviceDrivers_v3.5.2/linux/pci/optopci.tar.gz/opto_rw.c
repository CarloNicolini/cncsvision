#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <time.h>

#include "optopci.h"

#define TOTLEN 1024*1024*4

int main( int argc, char **argv )
{
	pid_t pid;
	long long us;
	int fd, len, i, totlen = 0, verbose=0;
	unsigned char uch = 0, buff[1024*128];
	struct timeval start, end;

	if(argc == 2)
		if(*argv[1] == 'v')
			verbose = 1;

	fd = open("/dev/optopci", O_RDWR);
	if(fd < 0) {
		perror("open");
		return -1;
	}

	i = ioctl(fd, OPTOPCI_CARD_INIT, 0);
	if(i < 0) {
		printf("ioctl returned %d\n", i);
		return -1;
	}

	pid = fork();
	if(pid ==  -1) {
		perror( "fork");
		goto fail;
	}
	srand(pid+time(NULL));
	gettimeofday(&start, NULL);
	if(pid) {
		while(totlen < TOTLEN) {
			len = rand() % sizeof(buff);
			for(i=0; i<len; i++ )
				buff[i] = uch++;
			if((totlen + len) > TOTLEN)
				len = TOTLEN - totlen;

			i = write(fd, buff, len);
			if(verbose)
				printf("write %d returned %d (%d)\n",
				       len, i, totlen);
			if(i != len) {
				perror("write");
				goto fail;
			}
			totlen += len;
		}
		gettimeofday(&end, NULL);
		us = (end.tv_sec * 1000000 + end.tv_usec) -
			(start.tv_sec * 1000000 + start.tv_usec);
		printf("write process finished: [%d B]/[%Ld us] -> %d bps\n",
		       totlen, us, (int)(8.0*(float)totlen/((float)us/1.0E6)));
		sleep(1);
	} else {
		while(totlen < TOTLEN) {
			len = rand() % sizeof(buff);
			if((totlen + len) > TOTLEN)
				len = TOTLEN - totlen;
			i = read(fd, buff, len);
			if(verbose)
				printf("read %d returned %d (%d) -> ",
				       len, i, totlen);
			if(i != len) {
				printf("\n");
				perror("read");
				goto fail;
			}
			for(i=0; i<len; i++) {
				if(buff[i] != uch++) {
					printf("data different!!!\n");
					goto fail;
				}
			}
			if(verbose)
				printf("OK!\n");
			totlen += len;
		}
		gettimeofday(&end, NULL);
		us = (end.tv_sec * 1000000 + end.tv_usec) -
			(start.tv_sec * 1000000 + start.tv_usec);
		printf("read process finished: [%d B]/[%Ld us] -> %d bps\n",
		       totlen, us, (int)(8.0*(float)totlen/((float)us/1.0E6)));
	}
 fail:	
	close(fd);
	return 0;
}
