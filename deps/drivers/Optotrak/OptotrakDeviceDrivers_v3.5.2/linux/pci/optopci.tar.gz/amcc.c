/*
 *  AMCC S5920 PCI Target Interface setup routines
 *
 *  Optotrak/PCI interface driver for Linux
 */
#include <linux/pci.h>
#include <linux/delay.h>
#include "optotrak.h"

static inline int amcc_readtag(struct amcc_regs *amcc);

/************************** exported function **************************/

/* initialize registers and load flex from eeprom */
int amcc_setup(struct amcc_regs *amcc)
{
	signed long time;

	/* write the AMCC registers */
	outl(PCI_AMCC_PTCR_DEFAULT, amcc->ptcr);
	outl(PCI_AMCC_RCR_DEFAULT, amcc->rcr);
	outl(PCI_AMCC_INTCSR_DEFAULT, amcc->intcsr);
	/* check writen values */
	if( (inl(amcc->ptcr) != PCI_AMCC_PTCR_DEFAULT) ||
	    (inl(amcc->rcr) != PCI_AMCC_RCR_DEFAULT) ||
	    (inl(amcc->intcsr) != PCI_AMCC_INTCSR_DEFAULT) ) {
		printk("AMCC initialization failed\n");
		return -1;
	}

	if(amcc_readtag(amcc) <= 0) {
		printk("Unable to read AMCC/PCI version tag\n");
		return -1;
	}

	/* Load Flex from Eeprom: */
	outl(PCI_DATA_BIT, amcc->omb);
	udelay(1);
	outl(PCI_DATA_BIT | PCI_START, amcc->omb);
	udelay(1);
	outl(PCI_DATA_BIT, amcc->omb);
	/* wait 100ms for Flex to load! */
	time = HZ/10;
	set_current_state(TASK_INTERRUPTIBLE);
	do {
		time = schedule_timeout(time);
	} while(time > 0);

	/* enable AMCC pass-thru interrupts */
	outl(PCI_AMCC_INTCSR_DEFAULT | PCI_AMCC_ENABLE_PT_INT,
	     amcc->intcsr);

	return 0;
}

/************************** internal functions **************************/

static inline void amcc_reset(struct amcc_regs *amcc);
static inline int amcc_readpage(struct amcc_regs *amcc,
				unsigned char *buff, unsigned long addr);

/* reads the revision information */
static inline int amcc_readtag(struct amcc_regs *amcc)
{
	unsigned char buff[EEPROM_PAGE_SIZE], tag[80];
	unsigned long index;
	int i, len;

	amcc_reset(amcc);
	index = (EEPROM_NUM_PAGES - 1) * EEPROM_PAGE_SIZE;
	
	if(amcc_readpage(amcc, buff, index) > 0) {
		/*
		 tag is at end of eeprom.  Search backward from back
		 of buffer to find the first "blank" byte.
		*/
		for(i = EEPROM_PAGE_SIZE - 1; i >= 0 && buff[i] != 0xff; i--);
		len = EEPROM_PAGE_SIZE - i;
		if(len >= sizeof(tag))
			len = sizeof(tag) - 1;

		if(len > 0) {
			memcpy(tag, buff + i + 1, len);
			tag[len-1]='\0';
			printk("AMCC tag: %s\n", tag);
		}
		return len;
	} else {
		printk("amcc_readpage failed\n");
		return -1;
	}
}

/* sends the start bit (called from readpage) */
static inline void amcc_startbit(struct amcc_regs *amcc)
{
	unsigned reg;

	reg = inl(amcc->omb);
	reg &= ~(PCI_READ_BACK | PCI_CLOCK_BIT);
	reg |= PCI_SER_EN;

	/* set up to write the start bit */
	reg |= PCI_DATA_BIT;	/* Clock = 0, Data = 1 */
	outl(reg, amcc->omb);
	udelay(1);

	/* clock in the data bit */
	reg |= PCI_CLOCK_BIT;	/* Clock = 1, Data = 1 */
	outl(reg, amcc->omb);
	udelay(1);

	/*
	  write the start bit which occurs on a transition from
	  data high to data low while the clock is high
	 */
	reg &= ~PCI_DATA_BIT;	/* Clock = 1, Data = 0 */
	outl(reg, amcc->omb);
	udelay(1);

	/* lower the clock line */
	reg &= ~PCI_CLOCK_BIT;	/* Clock = 0, Data = 0 */
	outl(reg, amcc->omb);
	udelay(1);
}

/* sends the stop bit (called from readpage) */
static inline void amcc_stopbit(struct amcc_regs *amcc)
{
	unsigned reg;

	reg = inl(amcc->omb);
	reg &= ~(PCI_READ_BACK | PCI_CLOCK_BIT);
	reg |= PCI_SER_EN;

	outl(reg, amcc->omb);
	udelay(1);

	/* set up clock */
	reg |= PCI_CLOCK_BIT;	/* Clock = 1, Data = 0 */
	outl(reg, amcc->omb);
	udelay(1);

	/*
	  stop bit is a transition of data from low to high
	  while clock is high
	*/
	reg |= PCI_DATA_BIT;		/* Clock = 1, Data = 1 */
	outl(reg, amcc->omb);
	udelay(1);

	/* lower the clock */
	reg &= ~PCI_CLOCK_BIT;		/* Clock = 0, Data = 1 */
	outl(reg, amcc->omb);
	udelay(1);
}

/* acknowledges a tranfer (called from readpage) */
static inline void amcc_sendack(struct amcc_regs *amcc)
{
	unsigned reg;

	reg = inl(amcc->omb);
	reg &= ~(PCI_READ_BACK | PCI_CLOCK_BIT | PCI_DATA_BIT);
	reg |= PCI_SER_EN;
	outl(reg, amcc->omb);
	udelay(1);

	/* toggle the clock */
	reg |= PCI_CLOCK_BIT;
	outl(reg, amcc->omb);
	udelay(1);
	reg &= ~PCI_CLOCK_BIT;
	outl(reg, amcc->omb);
	udelay(1);
	reg |= PCI_DATA_BIT;
	outl(reg, amcc->omb);
	udelay(1);
}

/* sends a byte of data MSB to LSB (called from readpage) */
static inline int amcc_sendbyte(struct amcc_regs *amcc, unsigned char byte)
{
	unsigned wreg, rreg;
	int bit, ret = 0;
	
	/* read current content of Out-going mailbox */
	wreg = inl(amcc->omb);
	wreg |= PCI_SER_EN;
	wreg &= ~(PCI_READ_BACK | PCI_CLOCK_BIT);
	outl(wreg, amcc->omb);
	udelay(1);

	for(bit=7; bit>=0; bit--) {
		/* set data bit to appropriate state */
		if(byte & (1 << bit))
			wreg |= PCI_DATA_BIT;
		else
			wreg &= ~PCI_DATA_BIT;
		outl(wreg, amcc->omb);
		udelay(1);

		/* clock in the data bit */
		wreg |= PCI_CLOCK_BIT;
		outl(wreg, amcc->omb);
		udelay(1);

		/* reset Clock to low */
		wreg &= ~PCI_CLOCK_BIT;
		outl(wreg, amcc->omb);
		udelay(1);
	}
	/* check for the ack */
	wreg |= PCI_READ_BACK | PCI_DATA_BIT;
	outl(wreg, amcc->omb);
	udelay(1);
	wreg |= PCI_CLOCK_BIT;
	outl(wreg, amcc->omb);
	udelay(1);

	/* read the IMB */
	rreg = inl(amcc->imb);
	if(!(rreg & PCI_DATA_BIT)) /* ack? */
		ret = 1;

	wreg &= ~(PCI_READ_BACK | PCI_CLOCK_BIT);
	wreg |= PCI_DATA_BIT;
	outl(wreg, amcc->omb);
	udelay(1);

	return ret;
}

/* reads a byte (called from readpage) */
static inline int amcc_readbyte(struct amcc_regs *amcc,
				unsigned char *byte)
{
	unsigned wreg, rreg, bit;

	/* read current content of Out-going mailbox */
	wreg = inl(amcc->omb);
	wreg |= PCI_SER_EN | PCI_DATA_BIT | PCI_READ_BACK;
	wreg &= ~PCI_CLOCK_BIT;
	outl(wreg, amcc->omb);
	udelay(1);

	*byte = 0;
	for(bit=0; bit<8; bit++) {
		/* raise the clock bit to shift out the next bit */
		wreg |= PCI_CLOCK_BIT;
		outl(wreg, amcc->omb);
		udelay(1);

		/* read in the current bit */
		rreg = inl(amcc->imb);
		if(rreg & PCI_DATA_BIT)
			*byte |= 1 << bit;

		/* lower the clock */
		wreg &= ~PCI_CLOCK_BIT;
		outl(wreg, amcc->omb);
		udelay(1);
	}
	return 1; /* why the return if there is no error check ???? */
}

/* resets the eeprom chip (called from amcc_readtag) */
static inline void amcc_reset(struct amcc_regs *amcc)
{
	int reset;

	/*
	  the Out-going Mailbox port of the AMCC chip is used to
	  control the EEPROM and Flex IC
	*/
	outl(PCI_SER_EN, amcc->omb);
	udelay(1);
	outl(PCI_RESET_ATMEL_EEPROM | PCI_SER_EN, amcc->omb);
	udelay(1);
	outl(PCI_SER_EN, amcc->omb);

	reset = inl(amcc->omb);

	udelay(1);
}

/* reads a page of data starting at address addr (called from amcc_readtag) */
static inline int amcc_readpage(struct amcc_regs *amcc,
		  unsigned char *buff, unsigned long addr)
{
	unsigned char ret = 0;
	int count = 0;

	/*
	  Put EEPROM into "Write Address" mode.  This may take several
	  attempts as the EEPROM may be in its internal timed write cycle!
	*/
	while(!ret) {
		amcc_startbit(amcc);
		/* send out the address bytes! */
		ret = amcc_sendbyte(amcc, EEPROM_WRITE_ADDRESS);
		if(!ret) {
			udelay(1);
			count++;
		}
		if(count > 100) {
			printk("amcc_readpage: count limit\n");
			return -1;
		}
	}

	/* send the address */
	if(!amcc_sendbyte(amcc, (addr >> 16) & 0xff ) ||
	   !amcc_sendbyte(amcc, (addr >> 8) & 0xff ) ||
	   !amcc_sendbyte(amcc, addr & 0xff ) ) {
		printk("amcc_readpage: failed writing addr\n");
		return -1;
	}

	/* send the start bits */
	amcc_startbit(amcc);

	/* set mode read address */
	if(!amcc_sendbyte(amcc, EEPROM_READ_ADDRESS)) {
		printk("amcc_readpage: failed setting read addr\n");
		return -1;
	}

	for(count = 0; count < EEPROM_PAGE_SIZE; count++, buff++) {
		/* read in a byte of data */
		if(!amcc_readbyte(amcc, buff)) {
			printk("amcc_readpage: failed reading byte\n");
			return -1;
		}
		if(count < (EEPROM_PAGE_SIZE - 1))
			amcc_sendack(amcc);
	}
	amcc_stopbit(amcc);
	return count;
}
