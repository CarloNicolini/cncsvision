#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>

#include "optopci.h"

#define TEST_STRING  "abcdefghijklmnopqrstuvwxyz???"
#define SIZE         (sizeof(TEST_STRING)+1)

int main( int argc, char **argv )
{
	int fd, i;
	char out[SIZE], in[SIZE];

	memcpy(out, TEST_STRING, SIZE);
	sync();
	sleep(1);

	fd = open( "/dev/optopci", O_RDWR );
	if( fd < 0 ) {
		perror("open");
		return -1;
	}
	printf( "/dev/optopci opened: %d\n", fd);

	i = ioctl(fd, OPTOPCI_CARD_INIT, 0);
	printf("ioctl returned %d\n", i);
	if(i < 0)
		return -1;

	printf("testing with %d bytes\n", SIZE);

	i = write(fd, out, SIZE);
	printf("write returned %d: -> %s\n", i, out);
	if(i < 0) {
		perror("write");
		return -1;
	}

	i = read(fd, in, SIZE);
	printf(" read returned %d: -> %s = ", i, in);
	if(i < 0) {
		perror("read");
		return -1;
	}

	if(strncmp(out, in, SIZE) == 0)
		printf("OK.\n");
	else
		printf("FAILED!\n");

	close(fd);
	return 0;
}
